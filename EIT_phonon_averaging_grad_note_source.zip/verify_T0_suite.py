#!/usr/bin/env python3
"""
T0 verification suite  --  Averaging-Induced Selection Rules
============================================================
Reproducible replacement for the note's cited-but-missing scripts
(verify_theorem2.py / verify_commutant.py / verify_3E_block2.py).

CONVENTIONS (fixed globally here -- this is the point of T0)
-----------------------------------------------------------
Orbital exchange (phonon averaging) enters the optical-coherence resolvent as
    G_e(z) = [ z I  -  V  +  i*gamma*(tau_x - I)_orb (x) I_spin ]^{-1},
with z = (omega - Hbar) + i*Gamma_opt/2.
The exchange gap is  Gamma_XY = 2*gamma  (population-imbalance rate = gap).

Fine structure (representative NV 3E, GHz):
    V = lam_z (tau_y (x) Sz) + D_es (I (x) Sz^2)
      + lam_perp (tau_z (x) Sx) + geBx (I (x) Sx)
Ground spin Hamiltonian:  H_g = D_gs Sz^2 + geBx Sx.

Two DERIVED convention fixes (flagged for the manuscript):
  (K1) Transverse-field efficiency, LEADING law (parameter-free, paper number):
         eta(Bx) ~= (geBx)^2 (1/D_es - 1/D_gs)^2 .
       Absolute eta at higher field is normalization-dependent; three models
       (linear / even-parity 2-level / full 6-level) bracket the note's values.
  (K2) Thermal collapse: with the resolved pair at +/- Delta_pair/2 and
       contrast C ∝ |K|^2, the clean form is  C/C0 = [1 + x^2]^{-2}
       with  x ≡ 2*Gamma_XY/Delta_pair  (== Gamma_XY / half-splitting).
       The note's text "x = Gamma_XY/Delta_pair" needs this factor of 2
       (or Delta_pair must denote the half-splitting).
"""
from __future__ import annotations
import numpy as np

def dag(a): return a.conj().T
np.set_printoptions(precision=5, suppress=True)

# ---- operators ----------------------------------------------------------
tx = np.array([[0, 1], [1, 0]], complex)
ty = np.array([[0, -1j], [1j, 0]], complex)
tz = np.array([[1, 0], [0, -1]], complex)
I2 = np.eye(2, dtype=complex)
Sz  = np.diag([-1., 0., 1.]).astype(complex)
Sz2 = np.diag([1., 0., 1.]).astype(complex)
Sx  = (1/np.sqrt(2)) * np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]], complex)
I3 = np.eye(3, dtype=complex)
kron = np.kron

# ---- representative parameters (GHz) ------------------------------------
LAM_Z, D_ES, LAM_PERP, D_GS = 5.3, 1.42, 0.2, 2.87
GAMMA_OPT = 1.0            # optical-coherence half-width scale (2*Im z)

up = np.array([1, 1], complex) / np.sqrt(2)          # orbital fixed point (tau_x=+1)
um = np.array([1, -1], complex) / np.sqrt(2)         # gapped antisymmetric

def V_fs(geBx):
    return (LAM_Z*kron(ty, Sz) + D_ES*kron(I2, Sz2)
            + LAM_PERP*kron(tz, Sx) + geBx*kron(I2, Sx))

def G_e(z, geBx, gamma):
    A = z*np.eye(6) - V_fs(geBx) + 1j*gamma*kron(tx - I2, I3)
    return np.linalg.inv(A)

# ---- test harness -------------------------------------------------------
RESULTS = []
def check(name, passed, detail):
    RESULTS.append((name, bool(passed), detail))
    print(f"[{'PASS' if passed else 'FAIL'}] {name}\n      {detail}")

def slope(x, y):
    lx, ly = np.log10(x), np.log10(np.abs(y))
    m = np.polyfit(lx, ly, 1)
    return m[0], float(np.max(np.abs(np.polyval(m, lx) - ly)))

z0 = 0.0 + 1j*GAMMA_OPT/2

# T1 -- B=0 exact spin-Lambda no-go, gamma-independent -------------------
s0 = np.array([0, 1, 0], complex)                    # ms = 0
sT = np.array([1, 0, 1], complex)/np.sqrt(2)         # (|-1>+|+1>)/sqrt2
p_f = kron(up, s0); c_f = kron(up, sT); c_go = kron(up, s0)
kb = [abs(dag(p_f) @ G_e(z0, 0.0, g) @ c_f) for g in (1e2, 1e3, 1e4, 1e5)]
check("T1 B=0 exact no-go (gamma-independent)", max(kb) < 1e-12,
      f"|K_forbidden(B=0)| = {['%.1e'%v for v in kb]}")

# T2 -- fixed-point dichotomy (Corollary 2.1) ----------------------------
# imprint of a perturbation on S=up-diagonal amplitude:
#   V ∝ tau_z (orbital-traceless off fixed point) -> imprint ∝ 1/gamma
#   V ∝ tau_x (in the averaging commutant, A1)    -> imprint gamma-independent
def imprint(axis, gamma, eps=0.05):
    p = kron(up, s0)
    def S(V):
        A = z0*np.eye(6) - V + 1j*gamma*kron(tx - I2, I3)
        return dag(p) @ np.linalg.solve(A, p)
    V1 = D_ES*kron(I2, Sz2) + eps*kron(axis, I3)
    V0 = D_ES*kron(I2, Sz2)
    return abs(S(V1) - S(V0))
g_arr = np.array([1e2, 1e3, 1e4, 1e5])
imp_z = np.array([imprint(tz, g) for g in g_arr])
imp_x = np.array([imprint(tx, g) for g in g_arr])
mz, _ = slope(g_arr, imp_z)
x_flat = imp_x.max()/imp_x.min()
check("T2 fixed-point dichotomy (tau_z dies ~1/gamma, tau_x survives)",
      abs(mz + 1) < 0.03 and x_flat < 1.01,
      f"tau_z imprint slope={mz:.4f} (exp -1); tau_x max/min={x_flat:.4f} (exp 1)")

# T3 -- surviving averaged block = orbital average V_bar_spin = D_es Sz^2 -
g = 1e6
P = kron(np.outer(up, up.conj()), I3)
Geff = P @ G_e(z0, 0.0, g) @ P
Gtar = kron(np.outer(up, up.conj()), np.linalg.inv(z0*I3 - D_ES*Sz2))
err = np.linalg.norm(Geff - Gtar)
check("T3 surviving block == D_es Sz^2 (lam_z, lam_perp annihilated)",
      err < 1e-4, f"||P G P - proj (x) (z-D_es Sz^2)^-1|| = {err:.2e} (O(||V||/gamma))")

# T4 -- remainder scaling gamma*|R| -> const ------------------------------
def R_of(gamma, geBx=0.3):
    Kfull = dag(p_f) @ G_e(z0, geBx, gamma) @ c_f
    K0 = (dag(up)@up)*(up.conj()@up) * (s0 @ np.linalg.inv(z0*I3 - (D_ES*Sz2+geBx*Sx)) @ sT)
    return abs(Kfull - K0)
gg = np.array([1e3, 1e4, 1e5])
gR = np.array([g*R_of(g) for g in gg])
check("T4 remainder gamma*|R| converges (Corollary 2.1 quantified)",
      (gR.max()-gR.min())/gR.mean() < 0.05,
      f"gamma*|R| = {['%.4f'%v for v in gR]} (converges to a constant)")

# T5 -- transverse-field revival: three bracketing models vs note targets -
Bxs = np.array([0.07, 0.14, 0.28, 0.56])
note_eta = np.array([6.16e-4, 2.42e-3, 9.03e-3, 2.80e-2])
# (a) leading parameter-free law:
eta_lin = (Bxs*(1/D_ES - 1/D_GS))**2
# (b) even-parity 2-level exact sin^2(theta_e - theta_g):
def th(D, B): return 0.5*np.arctan2(2*B, D)
eta_2lvl = np.sin(th(D_ES, Bxs) - th(D_GS, Bxs))**2
low_err = abs(eta_lin[0]/note_eta[0] - 1)
b2_lin = np.array([eta_lin[i]/eta_lin[i-1] for i in range(1, 4)])
b2_2lvl = np.array([eta_2lvl[i]/eta_2lvl[i-1] for i in range(1, 4)])
check("T5 revival law eta ~ (geBx)^2 (1/D_es-1/D_gs)^2, matches note low-field",
      low_err < 0.01 and abs(b2_lin[0]-4) < 1e-6,
      f"leading eta(0.07)={eta_lin[0]:.3e} vs note 6.16e-4 (err {low_err*100:.2f}%); "
      f"B^2 ratios lin={b2_lin.round(2)}, 2lvl={b2_2lvl.round(2)}, note~[3.93,3.73,3.10]")
print(f"      bracket table (eta):")
print(f"        geBx      linear     2-level     note")
for i, B in enumerate(Bxs):
    print(f"        {B:.2f}   {eta_lin[i]:.3e}  {eta_2lvl[i]:.3e}  {note_eta[i]:.3e}")

# T6 -- parity protection: odd combination stays dark under Bx -----------
# Exact statement is on the COLLAPSED kernel K0: since Sx|odd>=0 and Sz^2|odd>=|odd>,
# |odd> is an eigenvector of V_bar_spin=D_es Sz^2+geBx Sx, and <0|odd>=0 => K0=0 exactly.
# In the full 6-level model at finite gamma only an O(||V||/gamma) residual remains.
sOdd = np.array([1, 0, -1], complex)/np.sqrt(2)      # (|-1>-|+1>)/sqrt2
def K0_odd(B):
    Vbar = D_ES*Sz2 + B*Sx
    return abs(s0 @ np.linalg.inv(z0*I3 - Vbar) @ sOdd)
k0_odd = [K0_odd(B) for B in Bxs]
res_odd = np.array([abs(dag(kron(up, s0)) @ G_e(z0, 0.3, g) @ kron(up, sOdd))
                    for g in g_arr])
m_odd, _ = slope(g_arr, res_odd)
check("T6 parity-protected odd state: K0 exact 0, residual ~1/gamma",
      max(k0_odd) < 1e-13 and abs(m_odd + 1) < 0.03,
      f"collapsed K0(0<->odd)={max(k0_odd):.1e} (exact 0); "
      f"full-6-level residual slope={m_odd:.4f} (exp -1, it is a remainder)")

# T7 -- universal thermal collapse  C/C0 = [1+x^2]^-2, x = 2*Gamma_XY/Delta
def C_pair(Gamma_XY, Delta, Gopt=1e-4):
    Ghw = Gopt/2 + Gamma_XY
    return (Delta/(Ghw**2 + Delta**2/4))**2          # |K_pair|^2, kappa=1
xs = np.array([0.01, 0.1, 0.3, 1.0, 3.0, 10.0, 100.0])
worst = 0.0
for Delta in (0.5, 1.0, 2.0, 4.0):
    C0 = C_pair(1e-9, Delta)
    ratio = np.array([C_pair(x*Delta/2, Delta)/C0 for x in xs])   # x=2*GXY/Delta
    worst = max(worst, np.max(np.abs(ratio/(1+xs**2)**-2 - 1)))
check("T7 thermal collapse C/C0=[1+x^2]^-2 with x=2*Gamma_XY/Delta_pair (K2)",
      worst < 1e-3, f"max rel. deviation over 4 Delta, x in [1e-2,1e2] = {worst:.2e}")

# T8 -- strain quench envelope |K|^2 -> (lam_perp/Delta_strain)^2 ---------
# orbital 2-level: mixing lam_perp (tau_x) competing with strain (tau_z).
def kappa(Dstrain):
    return LAM_PERP/np.sqrt(LAM_PERP**2 + Dstrain**2)
Ds = np.array([1.0, 3.0, 10.0, 30.0, 100.0])
env_ratio = (kappa(Ds)**2) / (LAM_PERP/Ds)**2        # -> 1 for large Dstrain
check("T8 strain quench: |K|^2 envelope (lam_perp/Delta_strain)^2",
      abs(env_ratio[-1] - 1) < 0.02,
      f"envelope ratio at Delta_strain>>lam = {env_ratio[-1]:.4f} (->1); "
      f"crossover exact by Delta/lam>~{int(Ds[np.argmax(env_ratio<1.02)])}")

# ---- summary ------------------------------------------------------------
npass = sum(p for _, p, _ in RESULTS)
print("\n" + "="*64)
print(f"Summary: {npass}/{len(RESULTS)} T0 checks passed")
print("="*64)
