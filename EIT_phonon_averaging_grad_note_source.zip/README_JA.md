# フォノン平均化が導くEIT選択則：大学院生向け講義ノート

## 内容
- `EIT_phonon_averaging_grad_note_JA.tex`: 講義ノートのLaTeXソース
- `assets/`: 本文中の数値図
- `verify_T0_suite.py`: 添付理論の主要主張を検証するT0スイート
- `verify_T0_output.txt`: 再実行結果

## コンパイル
XeLaTeXを2回実行してください。

```bash
xelatex EIT_phonon_averaging_grad_note_JA.tex
xelatex EIT_phonon_averaging_grad_note_JA.tex
```

## 本資料で固定した規約
- 二枝交換gap: `Gamma_XY = 2 gamma`
- 励起pairは `+/- Delta_pair/2`
- 熱崩壊変数: `x = 2 Gamma_XY / Delta_pair`
- 横磁場効率の低磁場則は正規化に依存しないleading predictionとして扱う
